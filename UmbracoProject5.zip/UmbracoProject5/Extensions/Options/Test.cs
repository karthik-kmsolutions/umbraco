﻿using Microsoft.Identity.Web;
using System.Security.Claims;

namespace UmbracoProject5.Extensions.Options
{
    public static class Test
    {
        public static IUmbracoBuilder AddOpenIdConnectAuthenticationTest(this IUmbracoBuilder builder)
        {
            builder.Services.ConfigureOptions<OpenIdConnectBackOfficeExternalLoginProviderOptions>();

            builder.AddBackOfficeExternalLogins(extLoginBuilder =>
            {
                extLoginBuilder.AddBackOfficeLogin(
                     auth =>
                     {
                         auth.AddMicrosoftIdentityWebApp(options =>
                         {
                             var tenantId = "cb159329-dcf4-409d-adc0-31030aacef76";
                             var clientId = "5d588893-02d6-4153-80e1-8c8d6793bb0f";
                             var instance = "31h8Q~Hxema3J9w.GBZBIMvXqRazqX7c0fdLBckK";
                             options.CallbackPath = "/umbraco-signin-oidc";
                             options.Instance = instance;
                             options.TenantId = tenantId;
                             options.ClientId = clientId;
                             options.SignedOutRedirectUri = "/umbraco";

                             // Preferred over IClaimsTransformation which runs for every AuthenticateAsync
                             options.Events.OnTokenValidated = ctx =>
                             {
                                 var username = ctx.Principal?.Claims.FirstOrDefault(c => c.Type == ClaimConstants.PreferredUserName);
                                 if (username != null && ctx.Principal?.Identity is ClaimsIdentity claimsIdentity)
                                 {
                                     claimsIdentity.AddClaim(
                                         new Claim(
                                             ClaimTypes.Email,
                                             username.Value
                                         )
                                     );
                                 }

                                 return Task.CompletedTask;
                             };
                         },
                         openIdConnectScheme: auth.SchemeForBackOffice(Constants.AzureAd)); // also tried a custom scheme like $"{Constants.AzureAd}-skttl";
                     }
                     );
            });
            return builder;
        }
    }
}
