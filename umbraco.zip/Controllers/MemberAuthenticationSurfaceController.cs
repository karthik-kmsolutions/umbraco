﻿
using global::Umbraco.Cms.Core.Cache;
using global::Umbraco.Cms.Core.Logging;
using global::Umbraco.Cms.Core.Routing;
using global::Umbraco.Cms.Core.Security;
using global::Umbraco.Cms.Core.Services;
using global::Umbraco.Cms.Core.Web;
using global::Umbraco.Cms.Infrastructure.Persistence;
using global::Umbraco.Cms.Web.Common.Models;
using global::Umbraco.Cms.Web.Common.Security;
using global::Umbraco.Cms.Web.Website.Controllers;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ICIB.Umbraco.Controllers
{
    public class MemberAuthenticationSurfaceController : SurfaceController
    {
        private readonly IMemberManager _memberManager;
        private readonly IMemberSignInManager _memberSignInManager;
        public MemberAuthenticationSurfaceController(IUmbracoContextAccessor umbracoContextAccessor, IUmbracoDatabaseFactory databaseFactory, ServiceContext services, AppCaches appCaches, IProfilingLogger profilingLogger, IPublishedUrlProvider publishedUrlProvider, IMemberManager memberManager, IMemberSignInManager memberSignInManager) : base(umbracoContextAccessor, databaseFactory, services, appCaches, profilingLogger, publishedUrlProvider)
        {
            _memberManager = memberManager;
            _memberSignInManager = memberSignInManager;
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel loginModel, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if (await _memberManager.ValidateCredentialsAsync(loginModel.Username, loginModel.Password))
                {
                    var result = await _memberSignInManager.PasswordSignInAsync(loginModel.Username, loginModel.Password, false, true);
                    if (result.Succeeded)
                    {
                        if (Url.IsLocalUrl(returnUrl))
                        {
                            return Redirect(returnUrl);
                        }

                        return RedirectToCurrentUmbracoPage();
                    }

                }
                else
                {
                    ModelState.AddModelError(string.Empty, "The username or password provided is incorrect.");
                }
            }

            return CurrentUmbracoPage();
        }

        [HttpGet]
        public async Task<IActionResult> Logout(string RedirectUrl)
        {
            TempData.Clear();
            await _memberSignInManager.SignOutAsync();
			return Redirect(RedirectUrl);
		}
	}
}