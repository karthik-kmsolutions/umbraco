﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.MicrosoftAccount;
using Microsoft.Extensions.DependencyInjection;
using System.Security.Claims;
using Umbraco.Cms.Core.DependencyInjection;
using Umbraco.Extensions;

namespace ICIB.Core.Extensions.LoginProviders.Microsoft
{
    public static class BackofficeAuthenticationExtensions
    {
        public static IUmbracoBuilder ConfigureAuthentication(this IUmbracoBuilder builder)
        {
            builder.AddBackOfficeExternalLogins(logins =>
            {
                const string schema = MicrosoftAccountDefaults.AuthenticationScheme;

                logins.AddBackOfficeLogin(
                        backOfficeAuthenticationBuilder =>
                        {
                            backOfficeAuthenticationBuilder.AddMicrosoftAccount(
                                // the scheme must be set with this method to work for the back office
                                backOfficeAuthenticationBuilder.SchemeForBackOffice(schema) ?? string.Empty,
                                options =>
                                {
                                    //By default this is '/signin-microsoft' but it needs to be changed to this
                                    options.CallbackPath = "/umbraco-signin-microsoft/";
                                    options.ClientId = "36dcb3c2-1f41-4759-ac5b-b2687164afdf";
                                    options.ClientSecret = "BHM8Q~_cPky0eJ1yPAeR8JIXDVpZXeQ4VqDLudxC";
                                    options.SaveTokens = true;
                                    options.UserInformationEndpoint = "https://graph.microsoft.com/v1.0/me?$select=otherMails,displayName,givenName,surname,id";
                                    options.ClaimActions.MapCustomJson(ClaimTypes.Email, x =>
                                    {
                                        return "karthik.muni@exazeit.com";
                                    });
                                    options.TokenEndpoint = $"https://login.microsoftonline.com/ceecc926-0c8f-48d1-b01b-b17091c7d7f5/oauth2/v2.0/token";
                                    options.AuthorizationEndpoint = $"https://login.microsoftonline.com/ceecc926-0c8f-48d1-b01b-b17091c7d7f5/oauth2/v2.0/authorize";
                                });
                        });
            });
            return builder;
        }
    }
}