﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ICIB.Umbraco.Components
{

    public class ClientLogoutViewComponent : ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync()
        {
            return View("~/Views/Partials/_Logout.cshtml");
        }
    }
}
