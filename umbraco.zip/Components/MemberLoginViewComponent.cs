﻿using global::Umbraco.Cms.Web.Common.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ICIB.Umbraco.Components
{
    public class ClientLoginViewComponent : ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync()
        {
            return View("~/Views/Partials/_Login.cshtml", new LoginModel());
        }
    }
}